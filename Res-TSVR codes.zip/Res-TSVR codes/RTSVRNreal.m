function [RMSE] = RTSVRNreal(S)
for k=1:5
tic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%  DATA ANALYSIS AND DIVISION   %%%%%%%%%%%%
[ro,p]= size(S);
for j=1:p
   S(:,j) = (S(:,j) - min(S(:,j))) / ( max(S(:,j)) - min(S(:,j)));
end
S;
p=p-1;
nu= randperm(ro);
n= round(ro*0.7);
me = 0;
STD = 0.25;
TrainX = S(nu(1:n),:);
TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + STD*(randn(0.1*n,p+1)) + me;
%TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + sqrt(3)*STD*(rand(0.1*n,p+1)-0.5);
[roX,coX]=size(TrainX);
nuX= randperm(roX);
Datatrain.X= TrainX(nuX(1:n),1:p);
Datatrain.Y= TrainX(nuX(1:n),p+1);
TestX= S(nu(n+1:ro),1:p);
TestY= S(nu(n+1:ro), p+1);
TestX= (0.1:0.1:7.5);
TestX= TestX';
for i= 1:75
   TestY(i,1)= sin(TestX(i,1));
end
% ro=500;
% p=1;
% n=350;



%%%%%%%%%%%%  DATA ANALYSIS AND DIVISION   %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%  PARAMETERS AND PRE DEFINED TERMS   %%%%%%%%%%%%%%%

e= ones(n,1);
type = 'rbf';
for j=1:n
Dot(j,:) = kfun(Datatrain.X, type, Datatrain.X(j,:));
end
G= [Dot,e];
u1= ones(n+1,1);
u2= ones(n+1,1);
I= eye(n+1);
D1=0.1;
D2=0.1;
E1=0.05;
E2=0.05;
P = 0.2;
C1= 10^ (-1);
C2= 10^ (-1);

%%%%%%%%%%%%  PARAMETERS AND PRE DEFINED TERMS  %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%  ITERATIVE EQUATIONS   %%%%%%%%%%%%%%%
for i= 1:100
    one= (Datatrain.Y - E1*e - G*u1);
    two=(E1*e - Datatrain.Y + G*u1);
    if sum(one)<0
        one= zeros(n,1);
    end
    if sum(two)<0
        two= zeros(n,1);
    end
    
    three= (-Datatrain.Y - E2*e + G*u2);
    four=(E2*e + Datatrain.Y - G*u2);
    if sum(three)<0
        three= zeros(n,1);
    end
    if sum(four)<0
        four= zeros(n,1);
    end
    
    
    u1= (I/D1 + G'*G)\G'*((Datatrain.Y - E1*e) + C1/D1*((1-P)*one - P*two));
    u2= (I/D2 + G'*G)\G'*((Datatrain.Y + E2*e) + C2/D2*((P-1)*three + P*four));
 end
%%%%%%%%%%%%  ITERATIVE EQUATIONS   %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w1= u1(1:p);
w2= u2(1:p);
b1= u1(p+1); 
b2= u2(p+1);
b=(b1+b2)/2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%  PREDICTION   %%%%%%%%%%%%%%

%Y1 = w1'*TestX' + b1;
%Y2 = w2'*TestX' + b2;
%Y= ((w1+w2)'*TestX')/2 + b;

for j=1:ro-n
A(j,:)= kfun(Datatrain.X, type, TestX(j,:));
end
Y= [A, ones(ro-n,1)]*(u1+u2)/2;
% TestX
% TestY
% Y
%%%%%%%%%%%%  PREDICTION   %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% out1 = [2.5, 2.7, 2.8, 2.8, 3.1];
% out2 = [0.5, 0.6, 0.2, 0.7, 0.2];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%    GRAPH     %%%%%%%%%%%%%%
% %plot(nu(n+1:ro),TestY', 'o') 
% %hold on
% %plot(nu(n+1:ro),Y,'*')
% %legend({'Actual','Predicted'},'Location','northeast')
% %hold off
% 
% scatter (DatatrainX, DatatrainY, 'filled')
% hold on
% plot( TestX, TestY, 'g*') 
% plot( TestX, Y, 'ro')
% %scatter(out1, out2 , 'k', 'filled')
% legend('Training data', 'Actual data', 'Predicted data', 'Outliers')
% title('pin-TSVR(without noise)')
% hold off


%%%%%%%%%%%%%    GRAPH     %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%    ERROR    %%%%%%%%%%%%%
SSE= sumsqr(TestY-Y);
a= mean(TestY);
SST= sum((TestY - a).^2);
NMSE(k) =SSE/SST;


SSR = sum((TestY-Y).^2);


R_square(k)= 1-(SSR/SST);
 

SumSqr = (SSE'*SSE)/(ro-n);
RMSE1(k) = sqrt(mean((TestY - Y).^2));

timeElapsed(k)=toc;

%%%%%%%%%%%%%%    ERROR    %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
final_NMSE=mean(NMSE)
std_NMSE=std(NMSE)
R_square_fin=mean(R_square)
std_R_square=std(R_square)
RMSE1_fin=mean(RMSE1)
std_RMSE1=std(RMSE1)
final_time=mean(timeElapsed)
end
