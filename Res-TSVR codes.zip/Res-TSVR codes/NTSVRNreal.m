function [RMSE] = NTSVRNreal(S)
for k=1:10


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   ANALYSIS AND SPLITING OF DATASET   %%%%%%%%%%%%%%%%%%
[ro,p]= size(S);
for j=1:p
   S(:,j) = (S(:,j) - min(S(:,j))) / ( max(S(:,j)) - min(S(:,j)));
end

p=p-1;
nu= randperm(ro);
n= round(ro*0.70);

STD = 0.25;
TrainX = S(nu(1:n),:);
%%%%%%%%%%normal noise %%%%%%%%%%%%%%%
TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + STD*(randn(0.1*n,p+1))*2 ;

%%%%%%%%uniform noise%%%%%%%%%%%%%%%%%
%TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + sqrt(3)*STD*(rand(0.1*n,p+1)-0.5);

%%%%%%%%%%%%%%Impulse noise%%%%%%%%%%
% W=log(rand(0.1*n,p+1)).*sign(randn(0.1*n,p+1));
% TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + W/std(W(:))*STD;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[roX,coX]=size(TrainX);
nuX= randperm(roX);
Datatrain.X= TrainX(nuX(1:n),1:p);
Datatrain.Y= TrainX(nuX(1:n),p+1);
TestX= S(nu(n+1:ro),1:p);
TestY= S(nu(n+1:ro), p+1);

% ro=500;
% p=1;
% n=350;

tic

m=(1:ro-n);
type= 'rbf';
for j=1:n
    Dot(j,:) = kfun(Datatrain.X, type, Datatrain.X(j,:));
end
%%%%%%%%%%%%%%%   ANALYSIS AND SPLITING OF DATASET   %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   PARAMETERS AND PRE-DERINED TERMS   %%%%%%%%%%%%%%%%%%
tau=2;
U1=-1*ones(n,1);
U2=-1*ones(n,1);
eta= 9;
beta=1/(1-exp(-eta));
for iteration=1:tau
    e1= U1*(beta*eta);
    e2 = U2*(beta*eta);
    e = ones(n,1);
    G = [Dot,  e];
    I = eye(n+1);
    c1= 4;
    c2= 4;
    E1=0.05; 
    E2=0.05;
    A= zeros(1,n);
    %%%%%%%%%%%%%%%   PARAMETERS AND PRE-DERINED TERMS   %%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%       EQUATIONS AND CALCULATIONS     %%%%%%%%%%%%%%%%%%
    H1= G*((c1*(G')*G + I)\G');
    H2= G*((c2*(G')*G + I)\G');
    H1=(H1+H1')/2; H2=(H2+H2')/2;
    f= E1*e' + Datatrain.Y';
    h= Datatrain.Y' - E2* e';
    F1 = f - Datatrain.Y' * (H1);
    F2 = Datatrain.Y' * (H2) - h;
    options = optimoptions('quadprog','Algorithm','interior-point-convex','Display','none');
    alpha =  quadprog(H1,F1,A ,0 ,A ,0 ,A, -c1*e1,[],options);
    gamma =  quadprog(H2,F2,A ,0 ,A ,0 ,A, -c2*e2,[],options);
    u1 = ((c1*(G')*G + I)\G')*(c1* Datatrain.Y - alpha);
    u2 = ((c2*(G')*G +  I)\G')*(c2* Datatrain.Y + gamma);

    w1= u1(1:p);
    w2= u2(1:p);

    b1= u1(p+1);
    b2= u2(p+1);
    
    U1=-exp(-eta*max(0,ones(n,1)-(Datatrain.Y).*(((w1)'*Datatrain.X') + b1)'));
    U2=-exp(-eta*max(0,ones(n,1)-(Datatrain.Y).*(((w2)'*Datatrain.X') + b2)'));
    b=(b1+b2)/2;

    %%%%%%%%%%%%%%%       EQUATIONS AND CALCULATIONS     %%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%   PREDICTION   %%%%%%%%%%%%%
    
    %Y= [A, ones(ro-n,1)]*(u1+u2)/2;
   
    
    %%%%%%%%%%%%%%%   PREDICTION   %%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
    
    
end;
%Y1 = w1'*TestX' + b1;
%Y2 = w2'*TestX' + b2;
%Y= ((w1+w2)'*TestX')/2 + b;
for j=1:ro-n
        A(j,:)= kfun(Datatrain.X, type, TestX(j,:));
    
end
Y= [A, ones(ro-n,1)]*(u1+u2)/2;
SSE= sumsqr(TestY-Y);
a= mean(TestY);
SST= sum((TestY - a).^2);
NMSE(k) =SSE/SST;


SSR = sum((TestY-Y).^2);


R_square(k)= 1-(SSR/SST);
 

SumSqr = (SSE'*SSE)/(ro-n);
RMSE1(k) = sqrt(mean((TestY - Y).^2));

timeElapsed(k)=toc;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   GRAPH   %%%%%%%%%%%%%
%plot(m,TestY', 'r', 'linewidth',1.3) 
%hold on

%plot(m,Y,'B')
%legend({'Actual','Predicted'},'Location','northeast')
%hold off


% plot( TestX, TestY, '*') 
% hold on
% plot( TestX, Y, 'ro')
% hold off

%%%%%%%%%%%%%%%   GRAPH   %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%    ERROR    %%%%%%%%%%%%%

%Diff = TestY- Y';
%SumSqr = (Diff'*Diff)/(ro-n);
%RMSE = sqrt(SumSqr);

%%%%%%%%%%%%%%    ERROR    %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
final_NMSE=mean(NMSE)
std_NMSE=std(NMSE)
R_square_fin=mean(R_square)
std_R_square=std(R_square)
RMSE1_fin=mean(RMSE1)
std_RMSE1=std(RMSE1)
final_time=mean(timeElapsed)
end

