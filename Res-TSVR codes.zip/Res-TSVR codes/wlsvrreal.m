function [RMSE] = wlsvrreal(S)
for k=1:5
tic
[ro,p]= size(S);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%   ANALYSIS AND SPLITING OF DATASET   %%%%%%%%%%%%%%%%%%
for j=1:p
    S(:,j) = (S(:,j) - min(S(:,j))) / ( max(S(:,j)) - min(S(:,j)));
end


p=p-1;
nu= randperm(ro);
n= round(ro*0.7);
me = 0;
STD = 0.2;
TrainX = S(nu(1:n),:);
TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + STD*(randn(0.1*n,p+1)) + me;
%TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + sqrt(3)*STD*(rand(0.1*n,p+1)-0.5);
[roX,coX]=size(TrainX);
nuX= randperm(roX);
Datatrain.X= TrainX(nuX(1:n),1:p);
Datatrain.Y= TrainX(nuX(1:n),p+1);
TestX= S(nu(n+1:ro),1:p);
TestY= S(nu(n+1:ro), p+1);
m=(1:ro-n);
%%%%%%%%%%%%%%%   ANALYSIS AND SPLITING OF DATASET   %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% ro=500;
% p=1;
% n=350;
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   PARAMETERS AND PRE-DERINED TERMS   %%%%%%%%%%%%%%%%%%
tau=100;
C1=1;
C2=1;
v1=2^(2);
v2=2^(2);
E1=0.05;
E2=0.05;
D=eye(n);
e=ones(n,1);
type= 'rbf';
for j=1:n
    Dot(j,:) = kfun(Datatrain.X, type, Datatrain.X(j,:));
end
G = [Dot , e];
I = eye(n+1);
A= zeros(1,n);

H1= inv(D)/C1+G*((G'*G + v1*I)\G');
H2= inv(D)/C2+G*((G'*G + v2*I)\G');
H1=(H1+H1')/2; H2=(H2+H2')/2;
F1 = -(G*((G'*G + v1*I)\G'))*Datatrain.Y +Datatrain.Y+e*E1;
F2 = (G*((G'*G + v2*I)\G'))*Datatrain.Y -Datatrain.Y+e*E2;
alpha =  H1\e;
gamma =  H2\e;


beta1=1.9/C1;
beta2=1.9/C2;


for iteration=1:tau


    alpha=H1\((abs(H1*alpha+F1-beta1*alpha)+H1*alpha+F1-beta1*alpha)/2-F1);
    gamma=H2\((abs(H2*gamma+F2-beta2*gamma)+H2*gamma+F2-beta2*gamma)/2-F2);
    

end;

u1 = ((G'*G + v1*I)\G')*(Datatrain.Y - alpha);
u2 = ((G'*G + v2*I)\G')*(Datatrain.Y + gamma);

w1= u1(1:p);
w2= u2(1:p);

b1= u1(p+1);
b2= u2(p+1);
b=(b1+b2)/2;

% for j=1:ro-n
%         A(j,:)= kfun(Datatrain.X, type, TestX(j,:));
%     
% end
% Y= [A, ones(ro-n,1)]*(u1+u2)/2;
Y1 = w1'*TestX' + b1;
Y2 = w2'*TestX' +b2;
Y= (Datatrain.X*(w1+w2))/2 + b;

slack=abs(Datatrain.Y-Y);
J1=2.5;
J2=3;
a1=(abs(2*0.6745*slack/iqr(slack)))<=J1;
a2=(abs((2*0.6745*slack/iqr(slack)))).*(abs((2*0.6745*slack/iqr(slack)))<=J2);
a2=a2>J1;
a2=((J2-abs(2*0.6745*slack/iqr(slack)))/(J2-J1)).*a2;
a3=0.001*(abs(2*0.6745*slack/iqr(slack))>J2);
D=((a1+a2+a3)*ones(1,n)).*eye(n);
e=ones(n,1);
G = [Dot , e];
I = eye(n+1);
A= zeros(1,n);
H1= inv(D)/C1+G*((G'*G + v1*I)\G');
H2= inv(D)/C2+G*((G'*G + v2*I)\G');
H1=(H1+H1')/2; H2=(H2+H2')/2;
F1 = -(G*((G'*G + v1*I)\G'))*Datatrain.Y +Datatrain.Y+e*E1;
F2 = (G*((G'*G + v2*I)\G'))*Datatrain.Y -Datatrain.Y+e*E2;
beta1=1.9*min(a1+a2+a3)/C1;
beta2=1.9*min(a1+a2+a3)/C2;
for iteration=1:tau

    alpha=H1\((abs(H1*alpha+F1-beta1*alpha)+H1*alpha+F1-beta1*alpha)/2-F1);
    gamma=H2\((abs(H2*gamma+F2-beta2*gamma)+H2*gamma+F2-beta2*gamma)/2-F2);
    

end;


u1 = ((G'*G + v1*I)\G')*(Datatrain.Y - alpha);
u2 = ((G'*G + v2*I)\G')*(Datatrain.Y + gamma);

% w1= u1(1:p);
% w2= u2(1:p);
% 
% b1= u1(p+1);
% b2= u2(p+1);
% b=(b1+b2)/2;
% 
% 
% 
% Y= ((w1+w2)'*TestX')/2 + b;
for j=1:ro-n
        A(j,:)= kfun(Datatrain.X, type, TestX(j,:));
    
end
size(A);
Y= [A, ones(ro-n,1)]*(u1+u2)/2;
SSE= sumsqr(TestY-Y);
a= mean(TestY);
SST= sum((TestY - a).^2);
NMSE(k) =SSE/SST;


SSR = sum((TestY-Y).^2);


R_square(k)= 1-(SSR/SST);
 

SumSqr = (SSE'*SSE)/(ro-n);
RMSE1(k) = sqrt(mean((TestY - Y).^2));

timeElapsed(k)=toc;


% out1 = [3.5, 0.7, 0.5, 1, 1.3];
% out2 = [1, 2.6, 3.5, 2.1, 2.4];
% 
% Y
% scatter (DatatrainX, DatatrainY, 'filled')
% hold on
% plot( TestX, TestY, 'g*') 
% plot( TestX, Y, 'ro')
% %scatter(out1, out2 , 'k', 'filled')
% legend('Training data', 'Actual data', 'Predicted data', 'Outliers')
% title('W-ETSVR(with noise)')
% hold off
%%%%%%%%%%%%%%    ERROR    %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
final_NMSE=mean(NMSE)
std_NMSE=std(NMSE)
R_square_fin=mean(R_square)
std_R_square=std(R_square)
RMSE1_fin=mean(RMSE1)
std_RMSE1=std(RMSE1)
final_time=mean(timeElapsed)
end
