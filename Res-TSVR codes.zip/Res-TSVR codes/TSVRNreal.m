function [RMSE] = TSVRNreal(S)
tic
for k=1:10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   ANALYSIS AND SPLITING OF DATASET   %%%%%%%%%%%%%%%%%%
[ro,p]= size(S);
for j=1:p
   S(:,j) = (S(:,j) - min(S(:,j))) / ( max(S(:,j)) - min(S(:,j)));
end
p=p-1;
nu= randperm(ro);
n= round(ro*0.7);
me = 0;
STD = 0.25;
TrainX = S(nu(1:n),:);
TrainX(1:0.1*n,:) = TrainX(1:0.1*n,:) + STD*(randn(0.1*n,p+1))*2 ;
[roX,coX]=size(TrainX);
nuX= randperm(roX);
Datatrain.X= TrainX(nuX(1:n),1:p);
Datatrain.Y= TrainX(nuX(1:n),p+1);
TestX= S(nu(n+1:ro),1:p);
TestY= S(nu(n+1:ro), p+1);
%%%%%%%%%%%%%%%   ANALYSIS AND SPLITING OF DATASET   %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ro=500;
% p=1;
% n=350;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   PARAMETERS AND PRE-DERINED TERMS   %%%%%%%%%%%%%%%%%%
e= ones(n,1);
type= 'rbf';
for j=1:n
    Dot(j,:) = kfun(Datatrain.X, type, Datatrain.X(j,:));
end
G = [Dot  e];
I = eye(n+1);
c1= 10^(-3);
c2= 10^(-3);
E1=0.05; 
E2=0.05;
A= zeros(1,n);

%%%%%%%%%%%%%%%   PARAMETERS AND PRE-DERINED TERMS   %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%       EQUATIONS AND CALCULATIONS     %%%%%%%%%%%%%%%%%%
H1= G*((G'*G + I)\G');
H2= G*((G'*G + I)\G');
H1=(H1+H1')/2; H2=(H2+H2')/2;
f= Datatrain.Y - e*E1;
h= Datatrain.Y + e*E2;
F1 = f' - f'*H1;
F2 = h'*H2 - h';
options = optimoptions('quadprog', 'Algorithm', 'interior-point-convex', 'Display', 'none');
alpha =  quadprog(H1,F1,A ,0 ,A ,0 ,A, c1*e, [],options);
gamma =  quadprog(H2,F2,A ,0 ,A ,0 ,A, c2*e, [],options);

u1 = ((G'*G + I)\G')*(f - alpha);
u2 = ((G'*G + I)\G')*(h + gamma);
size(u2);
w1= u1(1:end-1);
w2= u2(1:end-1);

b1= u1(end);
b2= u2(end);
b=(b1+b2)/2;

%%%%%%%%%%%%%%%       EQUATIONS AND CALCULATIONS     %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   PREDICTION   %%%%%%%%%%%%%
for j=1:ro-n
    A(j,:)= kfun(Datatrain.X, type, TestX(j,:));
end
Y= [A, ones(ro-n,1)]*(u1+u2)/2;
%%%%%%%%%%%%%%%   PREDICTION   %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   GRAPH   %%%%%%%%%%%%%
%plot(nu(n+1:ro),TestY', 'r', 'linewidth',1.3) 
%hold on
%plot(nu(n+1:ro),Y,'b', 'linewidth',1.3)
%legend({'Actual','Predicted'},'Location','northeast')
%hold off






%%%%%%%%%%%%%%%   GRAPH   %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%    ERROR    %%%%%%%%%%%%%

SSE= sumsqr(TestY-Y);
a= mean(TestY);
SST= sumsqr(TestY - a);
NMSE(k) =SSE/SST;
SSR = sum((TestY-Y).^2);
R_square(k)= 1-(SSR/SST);
SumSqr = (SSE'*SSE)/(ro-n);
RMSE1(k) = sqrt(mean((TestY - Y).^2));
timeElapsed(k)=toc;


% out1 = [2.5, 2.7, 2.8, 2.8, 3.1];
% out2 = [0.5, 0.6, 0.2, 0.7, 0.2];
% TestX;
% Y;
% scatter (DatatrainX, DatatrainY, 'filled')
% hold on
% plot( TestX, TestY, 'g*') 
% plot( TestX, Y, '-')
% %scatter(out1, out2 , 'k', 'filled')
% legend('Training data', 'Actual data', 'Predicted data')
% title('TSVR(without noise)')
% hold off

%%%%%%%%%%%%%%    ERROR    %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
final_NMSE=mean(NMSE)
std_NMSE=std(NMSE)
R_square_fin=mean(R_square)
std_R_square=std(R_square)
RMSE1_fin=mean(RMSE1)
std_RMSE1=std(RMSE1)
final_time=mean(timeElapsed)
end