function G=kfun(x,type,xi)
if type=='rbf'
    for i=1:length(x)
        a = norm(xi - x(i,:));
        G(i)= exp(-3.5*(a^2)); 
    end
elseif type=='lin'
    for i=1:length(x)
        G(i)=x(i,:)*xi'; 
    end
elseif type=='pol'
    for i=1:length(x)
        G(i)=(x(i,:)*xi').^3; 
    end
end